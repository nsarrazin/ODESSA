%% M file script to provide data for twostage_aero.mdl model
clear twostage_aero_data; % remove any existing data structure
%% Block "const_3" has no data to save.
%% Block "power_3" has no data to save.
%% Block "plus_2" has no data to save.
%% Block "power_1" has no data to save.
%% Block "ALPHA11" wishes to save the following breakpoint vector:
twostage_aero_data.ALPHA11_pts = [[-10.0, -8.0, -6.0, -4.0, -2.0, 0.0, 2.0, 4.0, 6.0, 8.0, 10.0]];
%% Block "CD_fn" wishes to save the following data:
twostage_aero_data.CD_table_def = [
0.48, 0.38, 0.31, 0.25, 0.23, 0.21, 0.23, 0.25, 0.31, 0.38, 0.48];
%% Block "dragCoefficient" has no data to save.
%% Block "const_5" has no data to save.
%% Block "power_5" has no data to save.
%% Block "const_6" has no data to save.
%% Block "angleOfAttack" has no data to save.
%% Block "ALPHA1" wishes to save the following breakpoint vector:
twostage_aero_data.ALPHA1_pts = [[-10.0, -8.0, -6.0, -4.0, -2.0, 0.0, 2.0, 4.0, 6.0, 8.0, 10.0]];
%% Block "CL_fn" wishes to save the following data:
twostage_aero_data.CL_table_def = [
-1.6, -1.0, -0.73, -0.49, -0.24, 0.0, 0.24, 0.49, 0.73, 1.0, 1.6];
%% Block "liftCoefficient" has no data to save.
%% Block "ALPHA2" wishes to save the following breakpoint vector:
twostage_aero_data.ALPHA2_pts = [[-20.0, 0.0, 20.0]];
%% Block "Cm_fn" wishes to save the following data:
twostage_aero_data.Cm_table_def = [
0.6, 0.0, -0.6];
%% Block "pitchingMomentCoefficient" has no data to save.
%% Block "angleOfSideslip" has no data to save.
%% Block "BETA1" wishes to save the following breakpoint vector:
twostage_aero_data.BETA1_pts = [[-10.0, -8.0, -6.0, -4.0, -2.0, 0.0, 2.0, 4.0, 6.0, 8.0, 10.0]];
%% Block "CY_fn" wishes to save the following data:
twostage_aero_data.CY_table_def = [
1.6, 1.0, 0.73, 0.49, 0.24, 0.0, -0.24, -0.49, -0.73, -1.0, -1.6];
%% Block "sideforceCoefficient" has no data to save.
%% Block "BETA2" wishes to save the following breakpoint vector:
twostage_aero_data.BETA2_pts = [[-20.0, 0.0, 20.0]];
%% Block "Cn_fn" wishes to save the following data:
twostage_aero_data.Cn_table_def = [
-0.6, 0.0, 0.6];
%% Block "yawingMomentCoefficient" has no data to save.
%% Block "const_19" has no data to save.
%% Block "longitudinalReferenceLength" has no data to save.
%% Block "const_21" has no data to save.
%% Block "lateralReferencelength" has no data to save.
%% Block "const_23" has no data to save.
%% Block "referenceArea" has no data to save.
%% Block "const_28" has no data to save.
%% Block "rollingMomentCoefficient" has no data to save.
