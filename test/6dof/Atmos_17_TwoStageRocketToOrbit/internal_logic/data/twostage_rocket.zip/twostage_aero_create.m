%
% Invoke this script to create the corresponding model
%

% Create the system (either model or library) and open it

new_system('twostage_aero','Model');
load_system('simulink');
open_system('twostage_aero');
set_param('twostage_aero','Location', [70, 200, 670, 570]);
% pause(0.1); - disabled with R2006b/7.3; causes typeahead buffer overflow

% Execute the setup script to create the data structure
% in the model workspace for clarity

mws = get_param('twostage_aero','modelworkspace');
if ~exist('mws')
  error('Unable to open model workspace - aborting');
end
mws.clear;
mws.evalin('twostage_aero_data','twostage_aero_setup');
clear mws;

% Create the subsystem with proper size to accomodate in/out ports

add_block('built-in/subsystem','twostage_aero/twostage_aero','Position',[210, 45, 390, 320]);

% Flesh out subsystem with internal blocks

    add_block('built-in/Constant','twostage_aero/twostage_aero/const_3','ShowName','off','Value','2.','Position',[15,23,75,53]);
    add_block('built-in/Math','twostage_aero/twostage_aero/power_3','Operator','pow','Position',[95,19,125,58]);
    add_block('built-in/Sum','twostage_aero/twostage_aero/plus_2','IconShape','rectangular','Inputs','++','Position',[155,19,185,58]);
    add_block('built-in/Math','twostage_aero/twostage_aero/power_1','Operator','pow','Position',[205,19,235,58]);
    add_block('built-in/PreLookup','twostage_aero/twostage_aero/ALPHA11','FontSize',10,'Position',[245,12,295,64],'BreakpointsData','twostage_aero_data.ALPHA11_pts','BeginIndexSearchUsingPreviousIndexResult','on','ExtrapMethod','Linear','DiagnosticForOutOfRangeInput','None');
    add_block('built-in/Interpolation_n-D','twostage_aero/twostage_aero/CD_fn','FontSize',10,'Position',[305,13,355,63],'NumberOfTableDimensions','1','Table','twostage_aero_data.CD_table_def','ExtrapMethod','clip');
    add_block('built-in/Outport','twostage_aero/twostage_aero/dragCoefficient','Position',[365,31,395,45]);
    add_block('built-in/Constant','twostage_aero/twostage_aero/const_5','ShowName','off','Value','2.','Position',[15,74,75,104]);
    add_block('built-in/Math','twostage_aero/twostage_aero/power_5','Operator','pow','Position',[95,70,125,109]);
    add_block('built-in/Constant','twostage_aero/twostage_aero/const_6','ShowName','off','Value','0.5','Position',[15,113,75,143]);
    add_block('built-in/Inport','twostage_aero/twostage_aero/angleOfAttack','Position',[30,175,60,189]);
    add_block('built-in/PreLookup','twostage_aero/twostage_aero/ALPHA1','FontSize',10,'Position',[85,148,135,200],'BreakpointsData','twostage_aero_data.ALPHA1_pts','BeginIndexSearchUsingPreviousIndexResult','on','ExtrapMethod','Linear','DiagnosticForOutOfRangeInput','None');
    add_block('built-in/Interpolation_n-D','twostage_aero/twostage_aero/CL_fn','FontSize',10,'Position',[145,149,195,199],'NumberOfTableDimensions','1','Table','twostage_aero_data.CL_table_def','ExtrapMethod','clip');
    add_block('built-in/Outport','twostage_aero/twostage_aero/liftCoefficient','Position',[205,167,235,181]);
    add_block('built-in/PreLookup','twostage_aero/twostage_aero/ALPHA2','FontSize',10,'Position',[85,205,135,257],'BreakpointsData','twostage_aero_data.ALPHA2_pts','BeginIndexSearchUsingPreviousIndexResult','on','ExtrapMethod','Linear','DiagnosticForOutOfRangeInput','None');
    add_block('built-in/Interpolation_n-D','twostage_aero/twostage_aero/Cm_fn','FontSize',10,'Position',[145,206,195,256],'NumberOfTableDimensions','1','Table','twostage_aero_data.Cm_table_def','ExtrapMethod','clip');
    add_block('built-in/Outport','twostage_aero/twostage_aero/pitchingMomentCoefficient','Position',[205,224,235,238]);
    add_block('built-in/Inport','twostage_aero/twostage_aero/angleOfSideslip','Position',[30,289,60,303]);
    add_block('built-in/PreLookup','twostage_aero/twostage_aero/BETA1','FontSize',10,'Position',[85,262,135,314],'BreakpointsData','twostage_aero_data.BETA1_pts','BeginIndexSearchUsingPreviousIndexResult','on','ExtrapMethod','Linear','DiagnosticForOutOfRangeInput','None');
    add_block('built-in/Interpolation_n-D','twostage_aero/twostage_aero/CY_fn','FontSize',10,'Position',[145,263,195,313],'NumberOfTableDimensions','1','Table','twostage_aero_data.CY_table_def','ExtrapMethod','clip');
    add_block('built-in/Outport','twostage_aero/twostage_aero/sideforceCoefficient','Position',[205,281,235,295]);
    add_block('built-in/PreLookup','twostage_aero/twostage_aero/BETA2','FontSize',10,'Position',[85,319,135,371],'BreakpointsData','twostage_aero_data.BETA2_pts','BeginIndexSearchUsingPreviousIndexResult','on','ExtrapMethod','Linear','DiagnosticForOutOfRangeInput','None');
    add_block('built-in/Interpolation_n-D','twostage_aero/twostage_aero/Cn_fn','FontSize',10,'Position',[145,320,195,370],'NumberOfTableDimensions','1','Table','twostage_aero_data.Cn_table_def','ExtrapMethod','clip');
    add_block('built-in/Outport','twostage_aero/twostage_aero/yawingMomentCoefficient','Position',[205,338,235,352]);
    add_block('built-in/Constant','twostage_aero/twostage_aero/const_19','ShowName','off','Value','3','Position',[15,376,75,406]);
    add_block('built-in/Outport','twostage_aero/twostage_aero/longitudinalReferenceLength','Position',[95,384,125,398]);
    add_block('built-in/Constant','twostage_aero/twostage_aero/const_21','ShowName','off','Value','3','Position',[15,411,75,441]);
    add_block('built-in/Outport','twostage_aero/twostage_aero/lateralReferencelength','Position',[95,419,125,433]);
    add_block('built-in/Constant','twostage_aero/twostage_aero/const_23','ShowName','off','Value','7','Position',[15,446,75,476]);
    add_block('built-in/Outport','twostage_aero/twostage_aero/referenceArea','Position',[95,454,125,468]);
    add_block('built-in/Constant','twostage_aero/twostage_aero/const_28','ShowName','off','Value','0.','Position',[15,481,75,511]);
    add_block('built-in/Outport','twostage_aero/twostage_aero/rollingMomentCoefficient','Position',[95,489,125,503]);
    h=add_line('twostage_aero/twostage_aero','angleOfAttack/1','ALPHA1/1','autorouting','on');
    set_param(h,'Name','angleOfAttack');
    h=add_line('twostage_aero/twostage_aero','angleOfAttack/1','ALPHA2/1','autorouting','on');
    set_param(h,'Name','angleOfAttack');
    h=add_line('twostage_aero/twostage_aero','angleOfAttack/1','power_3/1','autorouting','on');
    set_param(h,'Name','angleOfAttack');
    h=add_line('twostage_aero/twostage_aero','angleOfSideslip/1','BETA1/1','autorouting','on');
    set_param(h,'Name','angleOfSideslip');
    h=add_line('twostage_aero/twostage_aero','angleOfSideslip/1','BETA2/1','autorouting','on');
    set_param(h,'Name','angleOfSideslip');
    h=add_line('twostage_aero/twostage_aero','angleOfSideslip/1','power_5/1','autorouting','on');
    set_param(h,'Name','angleOfSideslip');
    h=add_line('twostage_aero/twostage_aero','const_19/1','longitudinalReferenceLength/1','autorouting','on');
    set_param(h,'Name','longitudinalReferenceLength');
    h=add_line('twostage_aero/twostage_aero','const_21/1','lateralReferencelength/1','autorouting','on');
    set_param(h,'Name','lateralReferencelength');
    h=add_line('twostage_aero/twostage_aero','const_23/1','referenceArea/1','autorouting','on');
    set_param(h,'Name','referenceArea');
    h=add_line('twostage_aero/twostage_aero','power_1/1','ALPHA11/1','autorouting','on');
    set_param(h,'Name','totalAlpha');
    h=add_line('twostage_aero/twostage_aero','plus_2/1','power_1/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_aero/twostage_aero','power_3/1','plus_2/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_aero/twostage_aero','const_3/1','power_3/2','autorouting','on');
    set_param(h,'Name','const_3');
    h=add_line('twostage_aero/twostage_aero','power_5/1','plus_2/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_aero/twostage_aero','const_5/1','power_5/2','autorouting','on');
    set_param(h,'Name','const_5');
    h=add_line('twostage_aero/twostage_aero','const_6/1','power_1/2','autorouting','on');
    set_param(h,'Name','const_6');
    h=add_line('twostage_aero/twostage_aero','CL_fn/1','liftCoefficient/1','autorouting','on');
    set_param(h,'Name','liftCoefficient');
    h=add_line('twostage_aero/twostage_aero','CD_fn/1','dragCoefficient/1','autorouting','on');
    set_param(h,'Name','dragCoefficient');
    h=add_line('twostage_aero/twostage_aero','CY_fn/1','sideforceCoefficient/1','autorouting','on');
    set_param(h,'Name','sideforceCoefficient');
    h=add_line('twostage_aero/twostage_aero','const_28/1','rollingMomentCoefficient/1','autorouting','on');
    set_param(h,'Name','rollingMomentCoefficient');
    h=add_line('twostage_aero/twostage_aero','Cm_fn/1','pitchingMomentCoefficient/1','autorouting','on');
    set_param(h,'Name','pitchingMomentCoefficient');
    h=add_line('twostage_aero/twostage_aero','Cn_fn/1','yawingMomentCoefficient/1','autorouting','on');
    set_param(h,'Name','yawingMomentCoefficient');
    h=add_line('twostage_aero/twostage_aero','ALPHA1/1','CL_fn/1','autorouting','on');
    set_param(h,'Name','angleOfAttack_by_ALPHA1_k');
    h=add_line('twostage_aero/twostage_aero','ALPHA1/2','CL_fn/2','autorouting','on');
    set_param(h,'Name','angleOfAttack_by_ALPHA1_f');
    h=add_line('twostage_aero/twostage_aero','ALPHA11/1','CD_fn/1','autorouting','on');
    set_param(h,'Name','totalAlpha_by_ALPHA1_k');
    h=add_line('twostage_aero/twostage_aero','ALPHA11/2','CD_fn/2','autorouting','on');
    set_param(h,'Name','totalAlpha_by_ALPHA1_f');
    h=add_line('twostage_aero/twostage_aero','BETA1/1','CY_fn/1','autorouting','on');
    set_param(h,'Name','angleOfSideslip_by_BETA1_k');
    h=add_line('twostage_aero/twostage_aero','BETA1/2','CY_fn/2','autorouting','on');
    set_param(h,'Name','angleOfSideslip_by_BETA1_f');
    h=add_line('twostage_aero/twostage_aero','ALPHA2/1','Cm_fn/1','autorouting','on');
    set_param(h,'Name','angleOfAttack_by_ALPHA2_k');
    h=add_line('twostage_aero/twostage_aero','ALPHA2/2','Cm_fn/2','autorouting','on');
    set_param(h,'Name','angleOfAttack_by_ALPHA2_f');
    h=add_line('twostage_aero/twostage_aero','BETA2/1','Cn_fn/1','autorouting','on');
    set_param(h,'Name','angleOfSideslip_by_BETA2_k');
    h=add_line('twostage_aero/twostage_aero','BETA2/2','Cn_fn/2','autorouting','on');
    set_param(h,'Name','angleOfSideslip_by_BETA2_f');
    
    % Correct output numbers
    
    set_param('twostage_aero/twostage_aero/longitudinalReferenceLength','Port','1');
    set_param('twostage_aero/twostage_aero/lateralReferencelength','Port','2');
    set_param('twostage_aero/twostage_aero/referenceArea','Port','3');
    set_param('twostage_aero/twostage_aero/liftCoefficient','Port','4');
    set_param('twostage_aero/twostage_aero/dragCoefficient','Port','5');
    set_param('twostage_aero/twostage_aero/sideforceCoefficient','Port','6');
    set_param('twostage_aero/twostage_aero/rollingMomentCoefficient','Port','7');
    set_param('twostage_aero/twostage_aero/pitchingMomentCoefficient','Port','8');
    set_param('twostage_aero/twostage_aero/yawingMomentCoefficient','Port','9');

% Top-level inports and lines

add_block('built-in/Inport','twostage_aero/angleOfAttack','Position',[90, 88, 120, 102]);
add_line('twostage_aero','angleOfAttack/1','twostage_aero/1');
add_block('built-in/Inport','twostage_aero/angleOfSideslip','Position',[90, 268, 120, 282]);
add_line('twostage_aero','angleOfSideslip/1','twostage_aero/2');

% Top-level outports and lines

add_block('built-in/Outport','twostage_aero/longitudinalReferenceLength','Position',[480, 58, 510, 72]);
add_line('twostage_aero','twostage_aero/1','longitudinalReferenceLength/1');
add_block('built-in/Outport','twostage_aero/lateralReferencelength','Position',[480, 88, 510, 102]);
add_line('twostage_aero','twostage_aero/2','lateralReferencelength/1');
add_block('built-in/Outport','twostage_aero/referenceArea','Position',[480, 118, 510, 132]);
add_line('twostage_aero','twostage_aero/3','referenceArea/1');
add_block('built-in/Outport','twostage_aero/liftCoefficient','Position',[480, 148, 510, 162]);
add_line('twostage_aero','twostage_aero/4','liftCoefficient/1');
add_block('built-in/Outport','twostage_aero/dragCoefficient','Position',[480, 178, 510, 192]);
add_line('twostage_aero','twostage_aero/5','dragCoefficient/1');
add_block('built-in/Outport','twostage_aero/sideforceCoefficient','Position',[480, 208, 510, 222]);
add_line('twostage_aero','twostage_aero/6','sideforceCoefficient/1');
add_block('built-in/Outport','twostage_aero/rollingMomentCoefficient','Position',[480, 238, 510, 252]);
add_line('twostage_aero','twostage_aero/7','rollingMomentCoefficient/1');
add_block('built-in/Outport','twostage_aero/pitchingMomentCoefficient','Position',[480, 268, 510, 282]);
add_line('twostage_aero','twostage_aero/8','pitchingMomentCoefficient/1');
add_block('built-in/Outport','twostage_aero/yawingMomentCoefficient','Position',[480, 298, 510, 312]);
add_line('twostage_aero','twostage_aero/9','yawingMomentCoefficient/1');

% Add annotation

add_block('built-in/Note','twostage_aero/Auto-generated by DAVE2SL version 0.9.7 (2015-03-02)','Position',[300, 22]);

clear h;  % remove handle used for naming lines

% Pause so window can be drawn prior to verification

% pause(0.5); - disabled with R2006b/7.3; causes typeahead buffer overflow
if exist('twostage_aero_verify') == 2
  if twostage_aero_verify
    save_system('twostage_aero','twostage_aero');
    fprintf('\n"twostage_aero" model verified and saved.\n')
  else
    fprintf('\n"twostage_aero" model NOT VERIFIED; model has NOT been saved.\n')
  end
else
  save_system('twostage_aero','twostage_aero');
  fprintf('\n"twostage_aero" model saved.\n')
end

% twostage_aero model-building script was auto-generated 
% by DAVE2SL version 0.9.7 (2015-03-02)
% on Fri Feb 7 22:39:24 2020.
