%
% Invoke this script to create the corresponding model
%

% Create the system (either model or library) and open it

new_system('twostage_inertia','Model');
load_system('simulink');
open_system('twostage_inertia');
set_param('twostage_inertia','Location', [70, 200, 670, 690]);
% pause(0.1); - disabled with R2006b/7.3; causes typeahead buffer overflow

% Execute the setup script to create the data structure
% in the model workspace for clarity

mws = get_param('twostage_inertia','modelworkspace');
if ~exist('mws')
  error('Unable to open model workspace - aborting');
end
mws.clear;
mws.evalin('twostage_inertia_data','twostage_inertia_setup');
clear mws;

% Create the subsystem with proper size to accomodate in/out ports

add_block('built-in/subsystem','twostage_inertia/twostage_inertia','Position',[210, 45, 390, 440]);

% Flesh out subsystem with internal blocks

    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_12','ShowName','off','Value','0','Position',[15,24,75,54]);
    add_block('built-in/RelationalOperator','twostage_inertia/twostage_inertia/gt_12','Position',[85,20,115,59],'Operator','>');
    add_block('built-in/Switch','twostage_inertia/twostage_inertia/switch_9','Threshold','0.5','Position',[325,12,355,66]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_46','IconShape','rectangular','Inputs','+-','Position',[365,20,395,59]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyPositionOfCmWrtMrc_X','Position',[405,32,435,46]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_23','ShowName','off','Value','0','Position',[15,83,75,113]);
    add_block('built-in/RelationalOperator','twostage_inertia/twostage_inertia/gt_23','Position',[85,79,115,118],'Operator','>');
    add_block('built-in/Switch','twostage_inertia/twostage_inertia/switch_20','Threshold','0.5','Position',[325,71,355,125]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyMomentOfInertia_Roll','Position',[365,91,395,105]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_30','ShowName','off','Value','0','Position',[15,142,75,172]);
    add_block('built-in/RelationalOperator','twostage_inertia/twostage_inertia/gt_30','Position',[85,138,115,177],'Operator','>');
    add_block('built-in/Switch','twostage_inertia/twostage_inertia/switch_27','Threshold','0.5','Position',[325,130,355,184]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_34','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[365,138,395,177]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyMomentOfInertia_Yaw','Position',[405,150,435,164]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyMomentOfInertia_Pitch','Position',[365,189,395,203]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_34','ShowName','off','Value','1.0','Position',[15,208,75,238]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_39','ShowName','off','Value','0','Position',[15,255,75,285]);
    add_block('built-in/RelationalOperator','twostage_inertia/twostage_inertia/gt_39','Position',[85,251,115,290],'Operator','>');
    add_block('built-in/Switch','twostage_inertia/twostage_inertia/switch_36','Threshold','0.5','Position',[325,243,355,297]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/totalMass','Position',[365,263,395,277]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_44','ShowName','off','Value','0','Position',[15,314,75,344]);
    add_block('built-in/RelationalOperator','twostage_inertia/twostage_inertia/gt_44','Position',[85,310,115,349],'Operator','>');
    add_block('built-in/Switch','twostage_inertia/twostage_inertia/switch_43','Threshold','0.5','Position',[125,302,155,356]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/vrsPositionOfMrc','Position',[165,361,195,375]);
    add_block('built-in/Inport','twostage_inertia/twostage_inertia/rocketHasStaged','Position',[30,388,60,402]);
    add_block('built-in/Inport','twostage_inertia/twostage_inertia/stage1fuelConsumed','Position',[30,420,60,434]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_17','IconShape','rectangular','Inputs','+-','Position',[125,400,155,439]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/divide_16','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','*/','Position',[165,400,195,439]);
    add_block('built-in/Saturate','twostage_inertia/twostage_inertia/stage1FuelRemainingFrac_unlim_limiter','ShowName','off','LowerLimit','0.0','UpperLimit','1.0','AttributesFormatString','%<LowerLimit> to %<UpperLimit>','Position',[205,404,235,434]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_15','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,400,275,439]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_14','IconShape','rectangular','Inputs','++','Position',[285,400,315,439]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_26','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,444,275,483]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_25','IconShape','rectangular','Inputs','++','Position',[285,444,315,483]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_33','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,488,275,527]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_32','IconShape','rectangular','Inputs','++','Position',[285,488,315,527]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_42','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,532,275,571]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_41','IconShape','rectangular','Inputs','++','Position',[285,532,315,571]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/stage1FuelRemainingFrac','Position',[245,575,275,589]);
    add_block('built-in/Inport','twostage_inertia/twostage_inertia/stage2fuelConsumed','Position',[30,615,60,629]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_19','IconShape','rectangular','Inputs','+-','Position',[125,595,155,634]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/divide_18','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','*/','Position',[165,595,195,634]);
    add_block('built-in/Saturate','twostage_inertia/twostage_inertia/stage2FuelRemainingFrac_unlim_limiter','ShowName','off','LowerLimit','0.0','UpperLimit','1.0','AttributesFormatString','%<LowerLimit> to %<UpperLimit>','Position',[205,599,235,629]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_11','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,595,275,634]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_10','IconShape','rectangular','Inputs','++','Position',[285,595,315,634]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_22','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,639,275,678]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_21','IconShape','rectangular','Inputs','++','Position',[285,639,315,678]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_29','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,683,275,722]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_28','IconShape','rectangular','Inputs','++','Position',[285,683,315,722]);
    add_block('built-in/Product','twostage_inertia/twostage_inertia/times_38','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[245,727,275,766]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/plus_37','IconShape','rectangular','Inputs','++','Position',[285,727,315,766]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/stage2FuelRemainingFrac','Position',[245,770,275,784]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_49','ShowName','off','Value','16.918790','Position',[15,789,75,819]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_50','ShowName','off','Value','4.797980','Position',[15,824,75,854]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_51','ShowName','off','Value','16.91879','Position',[15,864,75,894]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_1','IconShape','rectangular','Inputs','+-','Position',[85,860,115,899]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_52','ShowName','off','Value','9.421642','Position',[15,903,75,933]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_53','ShowName','off','Value','4.79798','Position',[15,943,75,973]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_2','IconShape','rectangular','Inputs','+-','Position',[85,939,115,978]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_54','ShowName','off','Value','3.947368','Position',[15,982,75,1012]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_55','ShowName','off','Value','314000','Position',[15,1022,75,1052]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_3','IconShape','rectangular','Inputs','+-','Position',[85,1018,115,1057]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_56','ShowName','off','Value','134000','Position',[15,1061,75,1091]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_57','ShowName','off','Value','99000','Position',[15,1101,75,1131]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_4','IconShape','rectangular','Inputs','+-','Position',[85,1097,115,1136]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_58','ShowName','off','Value','19000','Position',[15,1140,75,1170]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_59','ShowName','off','Value','353250','Position',[15,1180,75,1210]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_5','IconShape','rectangular','Inputs','+-','Position',[85,1176,115,1215]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_60','ShowName','off','Value','150750','Position',[15,1219,75,1249]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_61','ShowName','off','Value','111375','Position',[15,1259,75,1289]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_6','IconShape','rectangular','Inputs','+-','Position',[85,1255,115,1294]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_62','ShowName','off','Value','21375','Position',[15,1298,75,1328]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_63','ShowName','off','Value','33501637.473461','Position',[15,1338,75,1368]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_7','IconShape','rectangular','Inputs','+-','Position',[85,1334,115,1373]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_64','ShowName','off','Value','10886636.572139','Position',[15,1377,75,1407]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_65','ShowName','off','Value','941063.762626','Position',[15,1417,75,1447]);
    add_block('built-in/Sum','twostage_inertia/twostage_inertia/minus_8','IconShape','rectangular','Inputs','+-','Position',[85,1413,115,1452]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_66','ShowName','off','Value','212384.868421','Position',[15,1456,75,1486]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_74','ShowName','off','Value','0.0','Position',[15,1491,75,1521]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyProductOfInertia_ZX','Position',[85,1499,115,1513]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_76','ShowName','off','Value','0.0','Position',[15,1526,75,1556]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyProductOfInertia_XY','Position',[85,1534,115,1548]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_78','ShowName','off','Value','0.0','Position',[15,1561,75,1591]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyProductOfInertia_YZ','Position',[85,1569,115,1583]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_83','ShowName','off','Value','0.','Position',[15,1596,75,1626]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyPositionOfCmWrtMrc_Y','Position',[85,1604,115,1618]);
    add_block('built-in/Constant','twostage_inertia/twostage_inertia/const_85','ShowName','off','Value','0.','Position',[15,1631,75,1661]);
    add_block('built-in/Outport','twostage_inertia/twostage_inertia/bodyPositionOfCmWrtMrc_Z','Position',[85,1639,115,1653]);
    h=add_line('twostage_inertia/twostage_inertia','rocketHasStaged/1','gt_12/1','autorouting','on');
    set_param(h,'Name','rocketHasStaged');
    h=add_line('twostage_inertia/twostage_inertia','rocketHasStaged/1','gt_23/1','autorouting','on');
    set_param(h,'Name','rocketHasStaged');
    h=add_line('twostage_inertia/twostage_inertia','rocketHasStaged/1','gt_30/1','autorouting','on');
    set_param(h,'Name','rocketHasStaged');
    h=add_line('twostage_inertia/twostage_inertia','rocketHasStaged/1','gt_39/1','autorouting','on');
    set_param(h,'Name','rocketHasStaged');
    h=add_line('twostage_inertia/twostage_inertia','rocketHasStaged/1','gt_44/1','autorouting','on');
    set_param(h,'Name','rocketHasStaged');
    h=add_line('twostage_inertia/twostage_inertia','stage1fuelConsumed/1','minus_17/2','autorouting','on');
    set_param(h,'Name','stage1fuelConsumed');
    h=add_line('twostage_inertia/twostage_inertia','stage2fuelConsumed/1','minus_19/2','autorouting','on');
    set_param(h,'Name','stage2fuelConsumed');
    h=add_line('twostage_inertia/twostage_inertia','const_49/1','switch_43/3','autorouting','on');
    set_param(h,'Name','fullVehicleMomentReferenceCenter');
    h=add_line('twostage_inertia/twostage_inertia','const_50/1','switch_43/1','autorouting','on');
    set_param(h,'Name','secondStageMomentReferenceCenter');
    h=add_line('twostage_inertia/twostage_inertia','const_51/1','minus_1/1','autorouting','on');
    set_param(h,'Name','Liftoff_XCG');
    h=add_line('twostage_inertia/twostage_inertia','const_52/1','minus_1/2','autorouting','on');
    set_param(h,'Name','S1Burnout_XCG');
    h=add_line('twostage_inertia/twostage_inertia','const_52/1','plus_14/1','autorouting','on');
    set_param(h,'Name','S1Burnout_XCG');
    h=add_line('twostage_inertia/twostage_inertia','const_53/1','minus_2/1','autorouting','on');
    set_param(h,'Name','S2Ignite_XCG');
    h=add_line('twostage_inertia/twostage_inertia','const_54/1','minus_2/2','autorouting','on');
    set_param(h,'Name','S2Burnout_XCG');
    h=add_line('twostage_inertia/twostage_inertia','const_54/1','plus_10/1','autorouting','on');
    set_param(h,'Name','S2Burnout_XCG');
    h=add_line('twostage_inertia/twostage_inertia','const_55/1','minus_3/1','autorouting','on');
    set_param(h,'Name','Liftoff_Mass');
    h=add_line('twostage_inertia/twostage_inertia','const_56/1','minus_3/2','autorouting','on');
    set_param(h,'Name','S1Burnout_Mass');
    h=add_line('twostage_inertia/twostage_inertia','const_56/1','plus_41/1','autorouting','on');
    set_param(h,'Name','S1Burnout_Mass');
    h=add_line('twostage_inertia/twostage_inertia','const_57/1','minus_4/1','autorouting','on');
    set_param(h,'Name','S2Ignite_Mass');
    h=add_line('twostage_inertia/twostage_inertia','const_58/1','minus_4/2','autorouting','on');
    set_param(h,'Name','S2Burnout_Mass');
    h=add_line('twostage_inertia/twostage_inertia','const_58/1','plus_37/1','autorouting','on');
    set_param(h,'Name','S2Burnout_Mass');
    h=add_line('twostage_inertia/twostage_inertia','const_59/1','minus_5/1','autorouting','on');
    set_param(h,'Name','Liftoff_Ixx');
    h=add_line('twostage_inertia/twostage_inertia','const_60/1','minus_5/2','autorouting','on');
    set_param(h,'Name','S1Burnout_Ixx');
    h=add_line('twostage_inertia/twostage_inertia','const_60/1','plus_25/1','autorouting','on');
    set_param(h,'Name','S1Burnout_Ixx');
    h=add_line('twostage_inertia/twostage_inertia','const_61/1','minus_6/1','autorouting','on');
    set_param(h,'Name','S2Ignite_Ixx');
    h=add_line('twostage_inertia/twostage_inertia','const_62/1','minus_6/2','autorouting','on');
    set_param(h,'Name','S2Burnout_Ixx');
    h=add_line('twostage_inertia/twostage_inertia','const_62/1','plus_21/1','autorouting','on');
    set_param(h,'Name','S2Burnout_Ixx');
    h=add_line('twostage_inertia/twostage_inertia','const_63/1','minus_7/1','autorouting','on');
    set_param(h,'Name','Liftoff_Iyy');
    h=add_line('twostage_inertia/twostage_inertia','const_64/1','minus_7/2','autorouting','on');
    set_param(h,'Name','S1Burnout_Iyy');
    h=add_line('twostage_inertia/twostage_inertia','const_64/1','plus_32/1','autorouting','on');
    set_param(h,'Name','S1Burnout_Iyy');
    h=add_line('twostage_inertia/twostage_inertia','const_65/1','minus_8/1','autorouting','on');
    set_param(h,'Name','S2Ignite_Iyy');
    h=add_line('twostage_inertia/twostage_inertia','const_66/1','minus_8/2','autorouting','on');
    set_param(h,'Name','S2Burnout_Iyy');
    h=add_line('twostage_inertia/twostage_inertia','const_66/1','plus_28/1','autorouting','on');
    set_param(h,'Name','S2Burnout_Iyy');
    h=add_line('twostage_inertia/twostage_inertia','minus_1/1','times_15/1','autorouting','on');
    set_param(h,'Name','stage1XCGRange');
    h=add_line('twostage_inertia/twostage_inertia','minus_2/1','times_11/1','autorouting','on');
    set_param(h,'Name','stage2XCGRange');
    h=add_line('twostage_inertia/twostage_inertia','minus_3/1','divide_16/2','autorouting','on');
    set_param(h,'Name','stage1FuelCapacity');
    h=add_line('twostage_inertia/twostage_inertia','minus_3/1','minus_17/1','autorouting','on');
    set_param(h,'Name','stage1FuelCapacity');
    h=add_line('twostage_inertia/twostage_inertia','minus_3/1','times_42/1','autorouting','on');
    set_param(h,'Name','stage1FuelCapacity');
    h=add_line('twostage_inertia/twostage_inertia','minus_4/1','divide_18/2','autorouting','on');
    set_param(h,'Name','stage2FuelCapacity');
    h=add_line('twostage_inertia/twostage_inertia','minus_4/1','minus_19/1','autorouting','on');
    set_param(h,'Name','stage2FuelCapacity');
    h=add_line('twostage_inertia/twostage_inertia','minus_4/1','times_38/1','autorouting','on');
    set_param(h,'Name','stage2FuelCapacity');
    h=add_line('twostage_inertia/twostage_inertia','minus_5/1','times_26/1','autorouting','on');
    set_param(h,'Name','stage1IxxRange');
    h=add_line('twostage_inertia/twostage_inertia','minus_6/1','times_22/1','autorouting','on');
    set_param(h,'Name','stage2IxxRange');
    h=add_line('twostage_inertia/twostage_inertia','minus_7/1','times_33/1','autorouting','on');
    set_param(h,'Name','stage1IyyRange');
    h=add_line('twostage_inertia/twostage_inertia','minus_8/1','times_29/1','autorouting','on');
    set_param(h,'Name','stage2IyyRange');
    h=add_line('twostage_inertia/twostage_inertia','switch_9/1','minus_46/2','autorouting','on');
    set_param(h,'Name','vrsPositionOfCM_X');
    h=add_line('twostage_inertia/twostage_inertia','plus_10/1','switch_9/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_11/1','plus_10/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','gt_12/1','switch_9/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','const_12/1','gt_12/2','autorouting','on');
    set_param(h,'Name','const_12');
    h=add_line('twostage_inertia/twostage_inertia','plus_14/1','switch_9/3','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_15/1','plus_14/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','divide_16/1','stage1FuelRemainingFrac_unlim_limiter/1','autorouting','on');
    set_param(h,'Name','stage1FuelRemainingFrac_unlim');
    h=add_line('twostage_inertia/twostage_inertia','minus_17/1','divide_16/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','divide_18/1','stage2FuelRemainingFrac_unlim_limiter/1','autorouting','on');
    set_param(h,'Name','stage2FuelRemainingFrac_unlim');
    h=add_line('twostage_inertia/twostage_inertia','minus_19/1','divide_18/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','switch_20/1','bodyMomentOfInertia_Roll/1','autorouting','on');
    set_param(h,'Name','bodyMomentOfInertia_Roll');
    h=add_line('twostage_inertia/twostage_inertia','plus_21/1','switch_20/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_22/1','plus_21/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','gt_23/1','switch_20/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','const_23/1','gt_23/2','autorouting','on');
    set_param(h,'Name','const_23');
    h=add_line('twostage_inertia/twostage_inertia','plus_25/1','switch_20/3','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_26/1','plus_25/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','switch_27/1','times_34/2','autorouting','on');
    set_param(h,'Name','bodyMomentOfInertia_Pitch');
    h=add_line('twostage_inertia/twostage_inertia','switch_27/1','bodyMomentOfInertia_Pitch/1','autorouting','on');
    set_param(h,'Name','bodyMomentOfInertia_Pitch');
    h=add_line('twostage_inertia/twostage_inertia','plus_28/1','switch_27/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_29/1','plus_28/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','gt_30/1','switch_27/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','const_30/1','gt_30/2','autorouting','on');
    set_param(h,'Name','const_30');
    h=add_line('twostage_inertia/twostage_inertia','plus_32/1','switch_27/3','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_33/1','plus_32/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_34/1','bodyMomentOfInertia_Yaw/1','autorouting','on');
    set_param(h,'Name','bodyMomentOfInertia_Yaw');
    h=add_line('twostage_inertia/twostage_inertia','const_34/1','times_34/1','autorouting','on');
    set_param(h,'Name','const_34');
    h=add_line('twostage_inertia/twostage_inertia','const_74/1','bodyProductOfInertia_ZX/1','autorouting','on');
    set_param(h,'Name','bodyProductOfInertia_ZX');
    h=add_line('twostage_inertia/twostage_inertia','const_76/1','bodyProductOfInertia_XY/1','autorouting','on');
    set_param(h,'Name','bodyProductOfInertia_XY');
    h=add_line('twostage_inertia/twostage_inertia','const_78/1','bodyProductOfInertia_YZ/1','autorouting','on');
    set_param(h,'Name','bodyProductOfInertia_YZ');
    h=add_line('twostage_inertia/twostage_inertia','switch_36/1','totalMass/1','autorouting','on');
    set_param(h,'Name','totalMass');
    h=add_line('twostage_inertia/twostage_inertia','plus_37/1','switch_36/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_38/1','plus_37/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','gt_39/1','switch_36/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','const_39/1','gt_39/2','autorouting','on');
    set_param(h,'Name','const_39');
    h=add_line('twostage_inertia/twostage_inertia','plus_41/1','switch_36/3','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','times_42/1','plus_41/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','switch_43/1','minus_46/1','autorouting','on');
    set_param(h,'Name','vrsPositionOfMrc');
    h=add_line('twostage_inertia/twostage_inertia','switch_43/1','vrsPositionOfMrc/1','autorouting','on');
    set_param(h,'Name','vrsPositionOfMrc');
    h=add_line('twostage_inertia/twostage_inertia','gt_44/1','switch_43/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_inertia/twostage_inertia','const_44/1','gt_44/2','autorouting','on');
    set_param(h,'Name','const_44');
    h=add_line('twostage_inertia/twostage_inertia','minus_46/1','bodyPositionOfCmWrtMrc_X/1','autorouting','on');
    set_param(h,'Name','bodyPositionOfCmWrtMrc_X');
    h=add_line('twostage_inertia/twostage_inertia','const_83/1','bodyPositionOfCmWrtMrc_Y/1','autorouting','on');
    set_param(h,'Name','bodyPositionOfCmWrtMrc_Y');
    h=add_line('twostage_inertia/twostage_inertia','const_85/1','bodyPositionOfCmWrtMrc_Z/1','autorouting','on');
    set_param(h,'Name','bodyPositionOfCmWrtMrc_Z');
    h=add_line('twostage_inertia/twostage_inertia','stage1FuelRemainingFrac_unlim_limiter/1','times_15/2','autorouting','on');
    set_param(h,'Name','stage1FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage1FuelRemainingFrac_unlim_limiter/1','times_26/2','autorouting','on');
    set_param(h,'Name','stage1FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage1FuelRemainingFrac_unlim_limiter/1','times_33/2','autorouting','on');
    set_param(h,'Name','stage1FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage1FuelRemainingFrac_unlim_limiter/1','times_42/2','autorouting','on');
    set_param(h,'Name','stage1FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage1FuelRemainingFrac_unlim_limiter/1','stage1FuelRemainingFrac/1','autorouting','on');
    set_param(h,'Name','stage1FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage2FuelRemainingFrac_unlim_limiter/1','times_11/2','autorouting','on');
    set_param(h,'Name','stage2FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage2FuelRemainingFrac_unlim_limiter/1','times_22/2','autorouting','on');
    set_param(h,'Name','stage2FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage2FuelRemainingFrac_unlim_limiter/1','times_29/2','autorouting','on');
    set_param(h,'Name','stage2FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage2FuelRemainingFrac_unlim_limiter/1','times_38/2','autorouting','on');
    set_param(h,'Name','stage2FuelRemainingFrac');
    h=add_line('twostage_inertia/twostage_inertia','stage2FuelRemainingFrac_unlim_limiter/1','stage2FuelRemainingFrac/1','autorouting','on');
    set_param(h,'Name','stage2FuelRemainingFrac');
    
    % Correct output numbers
    
    set_param('twostage_inertia/twostage_inertia/stage1FuelRemainingFrac','Port','1');
    set_param('twostage_inertia/twostage_inertia/stage2FuelRemainingFrac','Port','2');
    set_param('twostage_inertia/twostage_inertia/bodyMomentOfInertia_Roll','Port','3');
    set_param('twostage_inertia/twostage_inertia/bodyMomentOfInertia_Pitch','Port','4');
    set_param('twostage_inertia/twostage_inertia/bodyMomentOfInertia_Yaw','Port','5');
    set_param('twostage_inertia/twostage_inertia/bodyProductOfInertia_ZX','Port','6');
    set_param('twostage_inertia/twostage_inertia/bodyProductOfInertia_XY','Port','7');
    set_param('twostage_inertia/twostage_inertia/bodyProductOfInertia_YZ','Port','8');
    set_param('twostage_inertia/twostage_inertia/totalMass','Port','9');
    set_param('twostage_inertia/twostage_inertia/vrsPositionOfMrc','Port','10');
    set_param('twostage_inertia/twostage_inertia/bodyPositionOfCmWrtMrc_X','Port','11');
    set_param('twostage_inertia/twostage_inertia/bodyPositionOfCmWrtMrc_Y','Port','12');
    set_param('twostage_inertia/twostage_inertia/bodyPositionOfCmWrtMrc_Z','Port','13');

% Top-level inports and lines

add_block('built-in/Inport','twostage_inertia/rocketHasStaged','Position',[90, 83, 120, 97]);
add_line('twostage_inertia','rocketHasStaged/1','twostage_inertia/1');
add_block('built-in/Inport','twostage_inertia/stage1fuelConsumed','Position',[90, 238, 120, 252]);
add_line('twostage_inertia','stage1fuelConsumed/1','twostage_inertia/2');
add_block('built-in/Inport','twostage_inertia/stage2fuelConsumed','Position',[90, 393, 120, 407]);
add_line('twostage_inertia','stage2fuelConsumed/1','twostage_inertia/3');

% Top-level outports and lines

add_block('built-in/Outport','twostage_inertia/stage1FuelRemainingFrac','Position',[480, 58, 510, 72]);
add_line('twostage_inertia','twostage_inertia/1','stage1FuelRemainingFrac/1');
add_block('built-in/Outport','twostage_inertia/stage2FuelRemainingFrac','Position',[480, 88, 510, 102]);
add_line('twostage_inertia','twostage_inertia/2','stage2FuelRemainingFrac/1');
add_block('built-in/Outport','twostage_inertia/bodyMomentOfInertia_Roll','Position',[480, 118, 510, 132]);
add_line('twostage_inertia','twostage_inertia/3','bodyMomentOfInertia_Roll/1');
add_block('built-in/Outport','twostage_inertia/bodyMomentOfInertia_Pitch','Position',[480, 148, 510, 162]);
add_line('twostage_inertia','twostage_inertia/4','bodyMomentOfInertia_Pitch/1');
add_block('built-in/Outport','twostage_inertia/bodyMomentOfInertia_Yaw','Position',[480, 178, 510, 192]);
add_line('twostage_inertia','twostage_inertia/5','bodyMomentOfInertia_Yaw/1');
add_block('built-in/Outport','twostage_inertia/bodyProductOfInertia_ZX','Position',[480, 208, 510, 222]);
add_line('twostage_inertia','twostage_inertia/6','bodyProductOfInertia_ZX/1');
add_block('built-in/Outport','twostage_inertia/bodyProductOfInertia_XY','Position',[480, 238, 510, 252]);
add_line('twostage_inertia','twostage_inertia/7','bodyProductOfInertia_XY/1');
add_block('built-in/Outport','twostage_inertia/bodyProductOfInertia_YZ','Position',[480, 268, 510, 282]);
add_line('twostage_inertia','twostage_inertia/8','bodyProductOfInertia_YZ/1');
add_block('built-in/Outport','twostage_inertia/totalMass','Position',[480, 298, 510, 312]);
add_line('twostage_inertia','twostage_inertia/9','totalMass/1');
add_block('built-in/Outport','twostage_inertia/vrsPositionOfMrc','Position',[480, 328, 510, 342]);
add_line('twostage_inertia','twostage_inertia/10','vrsPositionOfMrc/1');
add_block('built-in/Outport','twostage_inertia/bodyPositionOfCmWrtMrc_X','Position',[480, 358, 510, 372]);
add_line('twostage_inertia','twostage_inertia/11','bodyPositionOfCmWrtMrc_X/1');
add_block('built-in/Outport','twostage_inertia/bodyPositionOfCmWrtMrc_Y','Position',[480, 388, 510, 402]);
add_line('twostage_inertia','twostage_inertia/12','bodyPositionOfCmWrtMrc_Y/1');
add_block('built-in/Outport','twostage_inertia/bodyPositionOfCmWrtMrc_Z','Position',[480, 418, 510, 432]);
add_line('twostage_inertia','twostage_inertia/13','bodyPositionOfCmWrtMrc_Z/1');

% Add annotation

add_block('built-in/Note','twostage_inertia/Auto-generated by DAVE2SL version 0.9.7 (2015-03-02)','Position',[300, 22]);

clear h;  % remove handle used for naming lines

% Pause so window can be drawn prior to verification

% pause(0.5); - disabled with R2006b/7.3; causes typeahead buffer overflow
if exist('twostage_inertia_verify') == 2
  if twostage_inertia_verify
    save_system('twostage_inertia','twostage_inertia');
    fprintf('\n"twostage_inertia" model verified and saved.\n')
  else
    fprintf('\n"twostage_inertia" model NOT VERIFIED; model has NOT been saved.\n')
  end
else
  save_system('twostage_inertia','twostage_inertia');
  fprintf('\n"twostage_inertia" model saved.\n')
end

% twostage_inertia model-building script was auto-generated 
% by DAVE2SL version 0.9.7 (2015-03-02)
% on Fri Feb 7 22:41:45 2020.
