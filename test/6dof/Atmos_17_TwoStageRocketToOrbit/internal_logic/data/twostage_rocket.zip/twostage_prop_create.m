%
% Invoke this script to create the corresponding model
%

% Create the system (either model or library) and open it

new_system('twostage_prop','Model');
load_system('simulink');
open_system('twostage_prop');
set_param('twostage_prop','Location', [70, 200, 670, 540]);
% pause(0.1); - disabled with R2006b/7.3; causes typeahead buffer overflow

% Execute the setup script to create the data structure
% in the model workspace for clarity

mws = get_param('twostage_prop','modelworkspace');
if ~exist('mws')
  error('Unable to open model workspace - aborting');
end
mws.clear;
mws.evalin('twostage_prop_data','twostage_prop_setup');
clear mws;

% Create the subsystem with proper size to accomodate in/out ports

add_block('built-in/subsystem','twostage_prop/twostage_prop','Position',[210, 45, 390, 290]);

% Flesh out subsystem with internal blocks

    add_block('built-in/Constant','twostage_prop/twostage_prop/const_2','ShowName','off','Value','0','Position',[15,24,75,54]);
    add_block('built-in/RelationalOperator','twostage_prop/twostage_prop/gt_2','Position',[85,20,115,59],'Operator','>');
    add_block('built-in/Switch','twostage_prop/twostage_prop/switch_1','Threshold','0.5','Position',[165,12,195,66]);
    add_block('built-in/Product','twostage_prop/twostage_prop/times_17','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','2','Position',[205,20,235,59]);
    add_block('built-in/Product','twostage_prop/twostage_prop/divide_16','Multiplication','Element-wise(.*)','SaturateOnIntegerOverflow','on','Inputs','*/','Position',[245,20,275,59]);
    add_block('built-in/Switch','twostage_prop/twostage_prop/switch_15','Threshold','0.5','Position',[285,12,315,66]);
    add_block('built-in/Outport','twostage_prop/twostage_prop/massDot','Position',[325,32,355,46]);
    add_block('built-in/Outport','twostage_prop/twostage_prop/isp','Position',[205,71,235,85]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_5','ShowName','off','Value','0','Position',[15,102,75,132]);
    add_block('built-in/RelationalOperator','twostage_prop/twostage_prop/gt_5','Position',[85,98,115,137],'Operator','>');
    add_block('built-in/Switch','twostage_prop/twostage_prop/switch_4','Threshold','0.5','Position',[125,90,155,144]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_6','ShowName','off','Value','0.001','Position',[15,149,75,179]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_9','ShowName','off','Value','0','Position',[15,196,75,226]);
    add_block('built-in/RelationalOperator','twostage_prop/twostage_prop/gt_9','Position',[85,192,115,231],'Operator','>');
    add_block('built-in/Switch','twostage_prop/twostage_prop/switch_8','Threshold','0.5','Position',[165,184,195,238]);
    add_block('built-in/RelationalOperator','twostage_prop/twostage_prop/gt_19','Position',[205,244,235,283],'Operator','>');
    add_block('built-in/Outport','twostage_prop/twostage_prop/bodyThrustForce_X','Position',[205,287,235,301]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_12','ShowName','off','Value','0','Position',[15,318,75,348]);
    add_block('built-in/RelationalOperator','twostage_prop/twostage_prop/gt_12','Position',[85,314,115,353],'Operator','>');
    add_block('built-in/Switch','twostage_prop/twostage_prop/switch_11','Threshold','0.5','Position',[125,306,155,360]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_13','ShowName','off','Value','0.','Position',[15,365,75,395]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_17','ShowName','off','Value','9.8066','Position',[15,400,75,430]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_19','ShowName','off','Value','0','Position',[15,435,75,465]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_20','ShowName','off','Value','0.','Position',[15,470,75,500]);
    add_block('built-in/Inport','twostage_prop/twostage_prop/stage1firing_flag','Position',[30,513,60,527]);
    add_block('built-in/Inport','twostage_prop/twostage_prop/stage2firing_flag','Position',[30,532,60,546]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_23','ShowName','off','Value','17000000','Position',[15,543,75,573]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_24','ShowName','off','Value','5000000','Position',[15,578,75,608]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_25','ShowName','off','Value','360','Position',[15,613,75,643]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_26','ShowName','off','Value','390','Position',[15,648,75,678]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_30','ShowName','off','Value','0','Position',[15,683,75,713]);
    add_block('built-in/Outport','twostage_prop/twostage_prop/bodyThrustForce_Y','Position',[85,691,115,705]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_32','ShowName','off','Value','0','Position',[15,718,75,748]);
    add_block('built-in/Outport','twostage_prop/twostage_prop/bodyThrustForce_Z','Position',[85,726,115,740]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_34','ShowName','off','Value','0','Position',[15,753,75,783]);
    add_block('built-in/Outport','twostage_prop/twostage_prop/bodyThrustMoment_Roll','Position',[85,761,115,775]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_36','ShowName','off','Value','0','Position',[15,788,75,818]);
    add_block('built-in/Outport','twostage_prop/twostage_prop/bodyThrustMoment_Pitch','Position',[85,796,115,810]);
    add_block('built-in/Constant','twostage_prop/twostage_prop/const_38','ShowName','off','Value','0','Position',[15,823,75,853]);
    add_block('built-in/Outport','twostage_prop/twostage_prop/bodyThrustMoment_Yaw','Position',[85,831,115,845]);
    h=add_line('twostage_prop/twostage_prop','stage1firing_flag/1','gt_2/1','autorouting','on');
    set_param(h,'Name','stage1firing_flag');
    h=add_line('twostage_prop/twostage_prop','stage1firing_flag/1','gt_9/1','autorouting','on');
    set_param(h,'Name','stage1firing_flag');
    h=add_line('twostage_prop/twostage_prop','stage2firing_flag/1','gt_5/1','autorouting','on');
    set_param(h,'Name','stage2firing_flag');
    h=add_line('twostage_prop/twostage_prop','stage2firing_flag/1','gt_12/1','autorouting','on');
    set_param(h,'Name','stage2firing_flag');
    h=add_line('twostage_prop/twostage_prop','const_23/1','switch_8/1','autorouting','on');
    set_param(h,'Name','stage1maxThrust');
    h=add_line('twostage_prop/twostage_prop','const_24/1','switch_11/1','autorouting','on');
    set_param(h,'Name','stage2maxThrust');
    h=add_line('twostage_prop/twostage_prop','const_25/1','switch_1/1','autorouting','on');
    set_param(h,'Name','stage1isp');
    h=add_line('twostage_prop/twostage_prop','const_26/1','switch_4/1','autorouting','on');
    set_param(h,'Name','stage2isp');
    h=add_line('twostage_prop/twostage_prop','switch_1/1','times_17/1','autorouting','on');
    set_param(h,'Name','isp');
    h=add_line('twostage_prop/twostage_prop','switch_1/1','isp/1','autorouting','on');
    set_param(h,'Name','isp');
    h=add_line('twostage_prop/twostage_prop','gt_2/1','switch_1/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_prop/twostage_prop','const_2/1','gt_2/2','autorouting','on');
    set_param(h,'Name','const_2');
    h=add_line('twostage_prop/twostage_prop','gt_5/1','switch_4/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_prop/twostage_prop','const_5/1','gt_5/2','autorouting','on');
    set_param(h,'Name','const_5');
    h=add_line('twostage_prop/twostage_prop','const_6/1','switch_4/3','autorouting','on');
    set_param(h,'Name','const_6');
    h=add_line('twostage_prop/twostage_prop','switch_4/1','switch_1/3','autorouting','on');
    set_param(h,'Name','switch_4');
    h=add_line('twostage_prop/twostage_prop','switch_8/1','divide_16/1','autorouting','on');
    set_param(h,'Name','bodyThrustForce_X');
    h=add_line('twostage_prop/twostage_prop','switch_8/1','gt_19/1','autorouting','on');
    set_param(h,'Name','bodyThrustForce_X');
    h=add_line('twostage_prop/twostage_prop','switch_8/1','bodyThrustForce_X/1','autorouting','on');
    set_param(h,'Name','bodyThrustForce_X');
    h=add_line('twostage_prop/twostage_prop','gt_9/1','switch_8/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_prop/twostage_prop','const_9/1','gt_9/2','autorouting','on');
    set_param(h,'Name','const_9');
    h=add_line('twostage_prop/twostage_prop','gt_12/1','switch_11/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_prop/twostage_prop','const_12/1','gt_12/2','autorouting','on');
    set_param(h,'Name','const_12');
    h=add_line('twostage_prop/twostage_prop','const_13/1','switch_11/3','autorouting','on');
    set_param(h,'Name','const_13');
    h=add_line('twostage_prop/twostage_prop','switch_11/1','switch_8/3','autorouting','on');
    set_param(h,'Name','switch_11');
    h=add_line('twostage_prop/twostage_prop','switch_15/1','massDot/1','autorouting','on');
    set_param(h,'Name','massDot');
    h=add_line('twostage_prop/twostage_prop','divide_16/1','switch_15/1','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_prop/twostage_prop','times_17/1','divide_16/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_prop/twostage_prop','const_17/1','times_17/2','autorouting','on');
    set_param(h,'Name','const_17');
    h=add_line('twostage_prop/twostage_prop','gt_19/1','switch_15/2','autorouting','on');
    set_param(h,'Name','unnamed');
    h=add_line('twostage_prop/twostage_prop','const_19/1','gt_19/2','autorouting','on');
    set_param(h,'Name','const_19');
    h=add_line('twostage_prop/twostage_prop','const_20/1','switch_15/3','autorouting','on');
    set_param(h,'Name','const_20');
    h=add_line('twostage_prop/twostage_prop','const_30/1','bodyThrustForce_Y/1','autorouting','on');
    set_param(h,'Name','bodyThrustForce_Y');
    h=add_line('twostage_prop/twostage_prop','const_32/1','bodyThrustForce_Z/1','autorouting','on');
    set_param(h,'Name','bodyThrustForce_Z');
    h=add_line('twostage_prop/twostage_prop','const_34/1','bodyThrustMoment_Roll/1','autorouting','on');
    set_param(h,'Name','bodyThrustMoment_Roll');
    h=add_line('twostage_prop/twostage_prop','const_36/1','bodyThrustMoment_Pitch/1','autorouting','on');
    set_param(h,'Name','bodyThrustMoment_Pitch');
    h=add_line('twostage_prop/twostage_prop','const_38/1','bodyThrustMoment_Yaw/1','autorouting','on');
    set_param(h,'Name','bodyThrustMoment_Yaw');
    
    % Correct output numbers
    
    set_param('twostage_prop/twostage_prop/isp','Port','1');
    set_param('twostage_prop/twostage_prop/bodyThrustForce_X','Port','2');
    set_param('twostage_prop/twostage_prop/massDot','Port','3');
    set_param('twostage_prop/twostage_prop/bodyThrustForce_Y','Port','4');
    set_param('twostage_prop/twostage_prop/bodyThrustForce_Z','Port','5');
    set_param('twostage_prop/twostage_prop/bodyThrustMoment_Roll','Port','6');
    set_param('twostage_prop/twostage_prop/bodyThrustMoment_Pitch','Port','7');
    set_param('twostage_prop/twostage_prop/bodyThrustMoment_Yaw','Port','8');

% Top-level inports and lines

add_block('built-in/Inport','twostage_prop/stage1firing_flag','Position',[90, 83, 120, 97]);
add_line('twostage_prop','stage1firing_flag/1','twostage_prop/1');
add_block('built-in/Inport','twostage_prop/stage2firing_flag','Position',[90, 243, 120, 257]);
add_line('twostage_prop','stage2firing_flag/1','twostage_prop/2');

% Top-level outports and lines

add_block('built-in/Outport','twostage_prop/isp','Position',[480, 58, 510, 72]);
add_line('twostage_prop','twostage_prop/1','isp/1');
add_block('built-in/Outport','twostage_prop/bodyThrustForce_X','Position',[480, 88, 510, 102]);
add_line('twostage_prop','twostage_prop/2','bodyThrustForce_X/1');
add_block('built-in/Outport','twostage_prop/massDot','Position',[480, 118, 510, 132]);
add_line('twostage_prop','twostage_prop/3','massDot/1');
add_block('built-in/Outport','twostage_prop/bodyThrustForce_Y','Position',[480, 148, 510, 162]);
add_line('twostage_prop','twostage_prop/4','bodyThrustForce_Y/1');
add_block('built-in/Outport','twostage_prop/bodyThrustForce_Z','Position',[480, 178, 510, 192]);
add_line('twostage_prop','twostage_prop/5','bodyThrustForce_Z/1');
add_block('built-in/Outport','twostage_prop/bodyThrustMoment_Roll','Position',[480, 208, 510, 222]);
add_line('twostage_prop','twostage_prop/6','bodyThrustMoment_Roll/1');
add_block('built-in/Outport','twostage_prop/bodyThrustMoment_Pitch','Position',[480, 238, 510, 252]);
add_line('twostage_prop','twostage_prop/7','bodyThrustMoment_Pitch/1');
add_block('built-in/Outport','twostage_prop/bodyThrustMoment_Yaw','Position',[480, 268, 510, 282]);
add_line('twostage_prop','twostage_prop/8','bodyThrustMoment_Yaw/1');

% Add annotation

add_block('built-in/Note','twostage_prop/Auto-generated by DAVE2SL version 0.9.7 (2015-03-02)','Position',[300, 22]);

clear h;  % remove handle used for naming lines

% Pause so window can be drawn prior to verification

% pause(0.5); - disabled with R2006b/7.3; causes typeahead buffer overflow
if exist('twostage_prop_verify') == 2
  if twostage_prop_verify
    save_system('twostage_prop','twostage_prop');
    fprintf('\n"twostage_prop" model verified and saved.\n')
  else
    fprintf('\n"twostage_prop" model NOT VERIFIED; model has NOT been saved.\n')
  end
else
  save_system('twostage_prop','twostage_prop');
  fprintf('\n"twostage_prop" model saved.\n')
end

% twostage_prop model-building script was auto-generated 
% by DAVE2SL version 0.9.7 (2015-03-02)
% on Fri Feb 7 22:42:27 2020.
